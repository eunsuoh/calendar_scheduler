import 'package:flutter/material.dart';
import 'package:calendar_scheduler/component/main_calender.dart';
import 'package:calendar_scheduler/component/schedule_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>{
  late DateTime selectedDate;

  @override
  void initState() {
    super.initState();
    selectedDate = DateTime.now();
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            MainCalender(
              selectedDate: selectedDate,
              onDaySelected: _onDaySelected, // 메서드로 변경
            ),
            ScheduleCard(
                startTime:12,
                endTime: 14,
                content: '프로그래밍 공부',
            ),
          ],
        ),
      ),
    );
  }

  void _onDaySelected(DateTime selectedDate, DateTime focusedDate) {
    setState(() {
      this.selectedDate = selectedDate;
    });
  }
}
